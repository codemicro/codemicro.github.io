To install this aircraft manually, please copy the following text into your 'aircraft.cfg',  inside the folder 'SimObjects\Airplanes\Aerosoft Airbus A320 CFM'. Replace the X in [FLTSIM.X] by the next following number (like [FLTSIM.8]) and put the snippet after the last FLTSIM-object. Then you copy the complete texture folder into the same aircraft folder where you find the aircraft.cfg. The easiest way: Just drag the complete ZIP-file into the livery manager and it will be installed automatically!

[FLTSIM.X]
title					= Airbus A320 ES-SAU SmartLynx Estonia
sim					= A320
model					= 
panel					=
sound					=
texture					= SmartLynxESSAU
kb_checklists				= 
kb_reference				= 
atc_id					= ES-SAU
atc_airline				= 
atc_flight_number			=
ui_manufacturer				= Airbus
ui_type					= A320-214 CFM 
ui_variation				= SmartLynx Estonia ES-SAU
ui_typerole				= Commercial Airliner
ui_createdby				= Aerosoft
atc_parking_types			= GATE, RAMP
atc_parking_codes   			= MYX
description				= Airbus A320 - 214 CFM / ES-SAU SmartLynx Estonia / Repaint by Thomas Pain https://www.dotmicron.com

